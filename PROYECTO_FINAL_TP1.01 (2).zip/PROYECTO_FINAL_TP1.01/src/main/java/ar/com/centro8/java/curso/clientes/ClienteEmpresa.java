package ar.com.centro8.java.curso.clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
// indica que al construir el texto del metodo ToString incluya tbm los
// atributos y
// la imformacion de la clase padre (CUenta)

public class ClienteEmpresa extends Cliente { // hereda de la clase Cliente
    private String nombreDeFantasia;
    private String cuit;

    // Constructor
    public ClienteEmpresa(int numeroDeCliente, String nombreDeFantasia, String cuit) {
        super(numeroDeCliente); // llama al constructor de la clase padre
        this.nombreDeFantasia = nombreDeFantasia;
        this.cuit = cuit;
    }
}
