package ar.com.centro8.java.curso.clientes;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString
@AllArgsConstructor 

public abstract class Cliente {// clase padre asbtracta, no se puede instanciar, solo se puede heredar
    private int numeroDeCliente;
}

