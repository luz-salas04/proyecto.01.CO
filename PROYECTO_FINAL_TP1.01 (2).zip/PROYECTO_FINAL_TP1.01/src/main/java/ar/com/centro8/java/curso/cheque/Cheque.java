package ar.com.centro8.java.curso.cheque;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor

public class Cheque {
    private final double monto; // el cheque se emite por un monto fijo
    private final String bancoEmisor; // el banco no cambia
    private final LocalDate fechaPago; // obtiene la fecha actual del sistema

}
