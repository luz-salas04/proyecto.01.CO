package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@ToString(callSuper = true) // indica que al construir el texto del metodo toString, incluya tambien los atributos y la información de la clase padre "cuenta"

public class CuentaConvertibilidad extends CuentaCorriente{ // esta clase hereda de CuentaCorriente, que a su vez hereda de Cuenta
    private double saldoDolares;


    //constructor
    public CuentaConvertibilidad(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente, montoDescubierto);
        this.saldoDolares = 0.0;
    }

    // metodo: depositar dolares
    public void depositarDolares(double monto){
        // Valida que el monto ingresado sea positivo y de ser así, lo suma a la variable saldoDolares
        if (monto>0)
            this.saldoDolares+=monto;
        else System.out.println("El monto a depositar debe ser mayor a cero");
    }

    // metodo: extraer dolares: (para los dolares no se acepta el giro en descubierto)
    public void extraerDolares(double monto){
        //Valida que el monto sea positivo y que haya dolares suficientes disponibles en la cuenta para recién ahi realizar el descuento
        if (monto>0 && monto<=saldoDolares)
            this.saldoDolares-=monto;
        else System.out.println("El monto a extraer debe ser mayor a cero y no puede exceder el saldo disponible");
    }

    // metodo para convertir pesos de la cuenta a dolares y acreditarlos en saldoDolares
    public void convertirPesosADolares(double montoPesos,double tasaDeCambio) {
        if (montoPesos>0 && getSaldo() >=montoPesos) {// descontamos los pesos de la cuenta principal
            setSaldo(getSaldo()-montoPesos);
            double dolaresObtenidos = montoPesos/tasaDeCambio;// calculamos los dolares y los sumamos al saldo en dolares
            this.saldoDolares +=dolaresObtenidos;
            System.out.println("Conversión exitosa. Se convirtieron " + montoPesos + " pesos a " + dolaresObtenidos + " dólares.");
        } else {
            System.out.println("No hay suficiente saldo en pesos para realizar la conversión.");
        }
    }

    // metodo para convertir dolares a pesos y acreditarlos en la cuenta principal
    public void convertirDolaresAPesos(double cantidadDolares, double tasaDeCambio) {
        if (cantidadDolares>0 && this.saldoDolares >= cantidadDolares) {
            this.saldoDolares -= cantidadDolares;// descontamos los dolares del saldo en dolares
            double pesosObtenidos = cantidadDolares * tasaDeCambio;//// calculamos los pesos obtenidos y los sumamos a la cuenta principal
            setSaldo(getSaldo() + pesosObtenidos);
            System.out.println("Conversión exitosa. Se convirtieron " + cantidadDolares + " dólares a " + pesosObtenidos + " pesos.");
        } else {
            System.out.println("No hay suficientes dólares disponibles para realizar la conversión.");
        }
    }
}