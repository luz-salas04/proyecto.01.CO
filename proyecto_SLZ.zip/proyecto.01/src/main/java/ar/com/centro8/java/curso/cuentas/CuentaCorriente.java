package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cheque.Cheque;
import ar.com.centro8.java.curso.clientes.Cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter  
@ToString(callSuper = true) 

public class CuentaCorriente extends Cuenta{
    private double montoDescubierto;

    public CuentaCorriente(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente);
        this.montoDescubierto = montoDescubierto;
    }

    // metodo depositar cheques: el cliente puede depositar un cheque
    public void depositarCheque(Cheque cheque){
        if(cheque.getMonto()<=0)
            System.out.println("no se puede depositar si esta en negativo ");
        else this.setSaldo(this.getSaldo()+cheque.getMonto());
            System.out.println("su saldo del cheque depositado es" +getSaldo());
    }

     // metodo Extraer efectivo: el cliente puede extraer dinero y utilizar su giro en descubierto en caso de que no tenga saldo suficiente
    public void extraerEfectivo(double monto){
        System.out.println("dispone de un monto autorizado");
        double saldoDisponible= getSaldo() + montoDescubierto;
        if (monto>0 && monto <= saldoDisponible) {
            // Restamos el monto al saldo de la cuenta, heredado de la Cuenta
            setSaldo(getSaldo()-monto);
            System.out.println("extraccion exitosa, saldo actual " + getSaldo());
        } else {
            System.out.println("fondo insuficiente, excede el saldo y el monto en descubierto");
        }
    }
}

