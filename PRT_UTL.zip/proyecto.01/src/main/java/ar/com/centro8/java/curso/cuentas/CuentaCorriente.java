package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cheque.Cheque;
import ar.com.centro8.java.curso.clientes.Cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter  
@ToString(callSuper = true) // llama a la clase padre e incorpora sus atributos 

public class CuentaCorriente extends Cuenta{
    private double montoDescubierto;
    private double montoAutorizado;

    public CuentaCorriente(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente);
        this.montoDescubierto = montoDescubierto;
    }

    // metodo Depositar cheques: el cliente puede depositar un cheque. Un cheque tiene un monto, un banco emisor y una fecha de pago 
    public void depositarCheque(Cheque cheque){
        if(cheque.getMonto()<=0)
            System.out.println("no se puede depositar si esta en negativo ");
        else this.setSaldo(this.getSaldo()+cheque.getMonto());
            System.out.println("su saldo del cheque depositado es" +getSaldo());
    }

     // Metodo Extraer efectivo: el cliente puede extraer dinero y utilizar su giro en descubierto en caso de que no tenga saldo suficiente
    public void extraerEfectivo(double monto){
        System.out.println("dispone de un monto autorizado");
        double montoAutorizado=60000;
        if (monto<=montoAutorizado)
            this.montoAutorizado-=monto;
        else System.out.println("tiene un limite de monto autorizado para extraer");
    }
}

