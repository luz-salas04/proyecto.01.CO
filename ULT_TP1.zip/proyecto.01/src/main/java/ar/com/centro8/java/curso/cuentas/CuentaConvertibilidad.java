package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@ToString(callSuper = true) // llama a la clase padre e incorpora sus atributos 

public class CuentaConvertibilidad extends CuentaCorriente{ // esta clase hereda de CuentaCorriente, que a su vez hereda de Cuenta
    private double saldoDolares;
    private double montoDolar;


    //constructor
    public CuentaConvertibilidad(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente, montoDescubierto);
        this.saldoDolares = 0.0;
    }

    // metodo: depositar dolares
    public void depositarDolares(double monto){
        // Valida que el monto ingresado sea positivo y de ser así, lo suma a la variable saldoDolares
        if (monto>0)
            this.saldoDolares+=monto;
        else System.out.println("El monto a depositar debe ser mayor a cero");
    }

    // metodo: extraer dolares: (para los dolares no se acepta el giro en descubierto)
    public void extraerDolares(double monto){
        //Valida que el monto sea positivo y que haya dolares suficientes disponibles en la cuenta para recién ahi realizar el descuento
        if (monto>0 && monto<=saldoDolares)
            this.saldoDolares-=monto;
        else System.out.println("El monto a extraer debe ser mayor a cero y no puede exceder el saldo disponible");
    }

    // metodo: convertir pesos a dolares. (La tasa de conversión será un parámetro)
    public void convertirPesosADolares(double montoPesos, double tasaDeCambio) {
        this.montoDolar=montoPesos/tasaDeCambio;
        System.out.println("los pesos convertidos a dolares son "+getMontoDolar());
    }

    // metodo: convertir dolares a pesos. (La tasa de conversión será un parámetro)
    public void convertirDolaresAPesos(double montoDolares, double tasaDeCambio){
        this.setSaldoDolares(montoDolares*tasaDeCambio);
        System.out.println("los dolares convertidos a pesos son "+getSaldoDolares());
    }
}
