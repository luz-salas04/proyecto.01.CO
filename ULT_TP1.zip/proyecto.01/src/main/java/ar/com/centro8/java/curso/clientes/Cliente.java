package ar.com.centro8.java.curso.clientes;

import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString
 


public abstract class Cliente {// clase padre asbtracta, no se puede instanciar, solo se puede heredar
    private int numeroDeCliente;

        public Cliente(int numeroDeCliente) {
        this.numeroDeCliente = numeroDeCliente;
    }
}
