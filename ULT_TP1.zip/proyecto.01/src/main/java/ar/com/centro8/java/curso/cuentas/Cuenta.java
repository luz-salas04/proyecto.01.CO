package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@ToString 

public abstract class Cuenta { //cuenta de padre abstracta
    private final int numeroCuenta;
    private final Cliente cliente; // clienteAsociado 
    @Setter private  double saldo; // permite modificar el saldo de la cuenta, ya que es un atributo privado 

    //Constructor
    public Cuenta(int numeroCuenta, Cliente cliente) {
        this.numeroCuenta = numeroCuenta;
        this.cliente = cliente;
        this.saldo = 0.0; // inicia en cero
    }

    //metodo para depositar dinero en la cuenta
    public void depositar(double monto){
        if (monto>0)
        this.saldo+=monto;
        else System.out.println("El monto a depositar debe ser mayor a cero");
    }

    //metodo para extraer dinero de la cuenta
    public void extraer(double monto){
        if (monto>0 && monto<=saldo) //el cliente puede extraer dinero sin excederse de su saldo
        this.saldo-=monto;
        else System.out.println("El monto a extraer debe ser mayor a cero y no puede exceder el saldo disponible");
    }    
}
