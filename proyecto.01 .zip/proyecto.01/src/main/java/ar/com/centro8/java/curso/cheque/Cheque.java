package ar.com.centro8.java.curso.cheque;

import java.time.LocalDate;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString 

public class Cheque {
    private final double monto; // inmutable, el cheque se emite por un monto fijo
    private final String bancoEmisor; // inmutable, el banco no cambia
    private final LocalDate fechaPago; // obtiene la fecha actual del sistema

    // constructor
    public Cheque(double monto, String bancoEmisor, LocalDate fechaPago) {
        this.monto = monto;
        this.bancoEmisor = bancoEmisor;
        this.fechaPago = fechaPago;
    }
}
