package ar.com.centro8.java.curso.test;


import java.time.LocalDate;

import ar.com.centro8.java.curso.cheque.Cheque;
import ar.com.centro8.java.curso.clientes.ClienteEmpresa;
import ar.com.centro8.java.curso.clientes.ClienteIndividual;
import ar.com.centro8.java.curso.cuentas.CuentaCorriente;
import ar.com.centro8.java.curso.cuentas.CuentaConvertibilidad;
import ar.com.centro8.java.curso.cuentas.CajaDeAhorro;


public class TestBanco {
    public static void main(String[] args) {
        
        System.out.println("== CREACIÓN DE CLIENTES == ");

        // Cliente Individual
        ClienteIndividual cliente1 = new ClienteIndividual(310, "Timothée", "Chalamet", "35123456");
        // Cliente Empresa
        ClienteEmpresa empresa1 = new ClienteEmpresa(202, "HYBE Corporation", "30-71123456-8");

        System.out.println("Cliente 1: " + cliente1.getNombre() + " " + cliente1.getApellido());
        System.out.println("Empresa 1: " + empresa1.getNombreDeFantasia() + " - CUIT: " + empresa1.getCuit());

        ///////////////////////////////////////////////////////////////////////////

        System.out.println("\n == PRUEBA DE CAJA DE AHORRO == ");

        // Caja de ahorro con numero de Cuenta, cliente y tasa de interes)
        CajaDeAhorro ca = new CajaDeAhorro(1001, cliente1, 0.05);
        
        ca.depositar(10000.0); 
        System.out.println("Saldo después del depósito: " + ca.getSaldo());
        ca.extraer(20000.0); // Extracción válida
        System.out.println("Saldo después de la extracción: " + ca.getSaldo());
        ca.extraer(100000.0); // Extracción fallida(EXCESO DE MONTO)
        System.out.println("Saldo después de la extracción fallida: " + ca.getSaldo());
        ca.cobrarInteres();
        System.out.println("Saldo después de cobrar intereses: " + ca.getSaldo());         

        //////////////////////////////////////////////////////////////////////////

        System.out.println("\n == PRUEBA DE CUENTA CORRIENTE == ");

        // Cuenta corriente con número de cuenta, cliente y monto giro en descubierto
        CuentaCorriente cc = new CuentaCorriente(2001, cliente1, 20000.0);
        
        cc.depositar(5000.0);
        System.out.println("Saldo después del depósito: " + cc.getSaldo());
        cc.extraer(30000.0);
        System.out.println("Saldo después de la extracción: " + cc.getSaldo());
        Cheque cheque1 = new Cheque(15000.0, "Banco Nacion", LocalDate.now());
        cc.depositarCheque(cheque1);
        System.out.println("Saldo después de depositar el cheque: " + cc.getSaldo()); 

        /////////////////////////////////////////////////////////////////////////

        System.out.println("\n == PRUEBA CUENTA CONVERTIBILIDAD == ");
        CuentaConvertibilidad cConv = new CuentaConvertibilidad(3001, empresa1, 50000.0);

        cConv.depositarDolares(200.0);
        cConv.extraerDolares(100.0);
        cConv.convertirPesosADolares(60000.0, 1200.0); 
        cConv.convertirDolaresAPesos(50.0, 1200.0);  

        System.out.println("Saldo Final  ARS: $" + cConv.getSaldo() + " USD: u$s " + cConv.getSaldoDolares());

    }
}
