package ar.com.centro8.java.curso.cuentas;

import java.time.LocalDate;

import ar.com.centro8.java.curso.cheque.Cheque;
import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter  
@ToString(callSuper = true) // llama a la clase padre e incorpora sus atributos 

public class CuentaCorriente extends Cuenta{
    private double montoDescubierto;

    // constructor
    public CuentaCorriente(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente);
        this.montoDescubierto = montoDescubierto;
    }

    // metodo Extraer efectivo: el cliente puede extraer dinero y utilizar su giro en descubierto en caso de que no tenga saldo suficiente
    @Override //Indica que este método está sobrescribiendo(modificando) el comportamiento de extracción original de la clase base Cuenta
    public void extraer(double monto) { 
        //Para extraer dinero de una cuenta corriente, el monto a retirar debe ser mayor a 0 y no debe sobrepasar la suma de mi saldo 
        // disponible mas el descubierto que me permite el banco. Si alcanza, actualizo el saldo restándole lo que retiré
        if (monto>0 && monto<=(getSaldo()+montoDescubierto)){ 
            setSaldo(getSaldo()-monto);
        }
    }

    // metodo Depositar cheques: el cliente puede depositar un cheque. Un cheque tiene un monto, un banco emisor y una fecha de pago
  
    public void depositarCheque(Cheque cheque) {

        if (cheque != null //Verifica que efectivamente se haya ingresado un objeto cheque (que no esté vacio  o sea nulo)
                && cheque.getMonto() > 0 //Consulta el monto del cheque con su getter y confirma que sea un valor positivo
                && cheque.getBancoEmisor() != null //Asegura que el cheque especifique la entidad bancaria que lo emite
                && cheque.getFechaPago() != null // verifica que la fecha de pago no esté vacia o sea nula
                && !cheque.getFechaPago().isAfter(LocalDate.now())) { // verifica que la fecha de pago no sea posterior a la fecha actual
            setSaldo(getSaldo() + cheque.getMonto());// si el cheque pasa todas las comprobaciones, le suma el valor del cheque al saldo actual de la cuenta
        }
    }
}

