package ar.com.centro8.java.curso.clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString (callSuper = true) // llama a la clase padre e incorpora sus atributos

public class ClienteIndividual extends Cliente {
    private String nombre;
    private String apellido;
    private String dni;


    //constructor
    public ClienteIndividual(int numeroDeCliente, String nombre, String apellido, String dni) {
        super(numeroDeCliente); // llama al constructor de la clase padre
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }
}
