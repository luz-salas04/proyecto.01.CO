package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter 
@ToString(callSuper = true) // llama a la clase padre e incorpora sus atributos 

public class CuentaConvertibilidad extends CuentaCorriente{ // esta clase hereda de CuentaCorriente, que a su vez hereda de Cuenta
    private double saldoDolares;


    //constructor
    public CuentaConvertibilidad(int numeroCuenta, Cliente cliente, double montoDescubierto) {
        super(numeroCuenta, cliente, montoDescubierto);
        this.saldoDolares = 0.0;
    }

    // metodo: depositar dolares
    public void depositarDolares(double monto){
        // Valida que el monto ingresado sea positivo y de ser así, lo suma a la variable saldoDolares
        if (monto>0){
            saldoDolares+=monto;
        }
    }

    // metodo: extraer dolares: (para los dolares no se acepta el giro en descubierto)
    public void extraerDolares(double monto){
        //Valida que el monto sea positivo y que haya dolares suficientes disponibles en la cuenta para recién ahi realizar el descuento
        if (monto>0 && monto<=saldoDolares){
            saldoDolares-=monto;
        }
    }

    // metodo: convertir pesos a dolares. (La tasa de conversión será un parámetro)
    public void convertirPesosADolares(double monto, double tasaConversion) {
        if (monto > 0 && monto <= getSaldo()) {
            double dolares = monto / tasaConversion; //Calcula cuantos dolares corresponden dividiendo los pesos entre la tasa de conversion
            setSaldo(getSaldo() - monto); //  Descuenta los pesos
            saldoDolares += dolares;   //  Aumenta los dólares
        }
    }

    // metodo: convertir dolares a pesos. (La tasa de conversión será un parámetro)
    public void convertirDolaresAPesos(double monto, double tasaConversion){
        if (monto>0 && monto<=saldoDolares){
            double pesos = monto * tasaConversion; //Calcula cuantos pesos se reciben multiplicando los dólares por la tasa de conversion
            saldoDolares -= monto; //descuenta los dolares 
            setSaldo(getSaldo() + pesos); // suma los pesos al saldo principal
        }
    }
}
