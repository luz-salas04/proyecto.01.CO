package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter 
@Setter 
@ToString (callSuper = true) // llama a la clase padre e incorpora sus atributos

public class CajaDeAhorro extends Cuenta {
    private double tasaInteres;


    //constructor
    public CajaDeAhorro(int numeroCuenta, Cliente cliente, double tasaInteres) {
        super(numeroCuenta, cliente);// llama al constructor de la clase padre
        this.tasaInteres = tasaInteres;
    }

    //metodo para cobrar interes
    public void cobrarInteres(){
        setSaldo(getSaldo()+(getSaldo()*tasaInteres));
    }
}
