package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter 

public abstract class Cuenta { //cuenta de padre abstracta
    private int numeroCuenta;
    private Cliente cliente;
    private double saldo;

    //Constructor
    public Cuenta(int numeroCuenta, Cliente cliente, double saldo) {
        this.numeroCuenta = numeroCuenta;
        this.cliente = cliente;
        this.saldo = saldo;
    }

    //metodo para depositar dinero en la cuenta
    public void depositar(double monto){
        if (monto>0){
            saldo+=monto;
        }
    }
    //metodo para extraer dinero de la cuenta
    public void extraer(double monto){
        if (monto>0 && monto<=saldo){
            saldo-=monto;
        }
    }


}
