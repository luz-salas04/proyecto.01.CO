package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.clientes.Cliente;

public class CajaDeAhorro extends Cuenta {
    private double tasaInteres;


    //constructor
    public CajaDeAhorro(int numeroCuenta, Cliente cliente, double saldo, double tasaInteres) {
        super(numeroCuenta, cliente, saldo);// llama al constructor de la clase padre
        this.tasaInteres = tasaInteres;
    }

    //metodo para extraer dinero de la cuenta, sobreescribe el metodo de la clase padre
    @Override
    public void extraer(double monto) {
        if (monto>0 && monto<=getSaldo()){
            setSaldo(getSaldo()-monto);
        }
    }

    //metodo para cobrar interes
    public void cobrarInteres(){
        setSaldo(getSaldo()+(getSaldo()*tasaInteres));
    }
}
