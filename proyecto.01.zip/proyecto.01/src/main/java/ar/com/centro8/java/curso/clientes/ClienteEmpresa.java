package ar.com.centro8.java.curso.clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter 
@ToString 

public class ClienteEmpresa  extends Cliente { // hereda de la clase Cliente
    private String nombreDeFantasia;
    private String cuit;

    //Constructor
    public ClienteEmpresa(int numeroCliente, String nombreDeFantasia, String cuit) {
        super(numeroCliente); // llama al constructor de la clase padre
        this.nombreDeFantasia = nombreDeFantasia;
        this.cuit = cuit;
    }
}
