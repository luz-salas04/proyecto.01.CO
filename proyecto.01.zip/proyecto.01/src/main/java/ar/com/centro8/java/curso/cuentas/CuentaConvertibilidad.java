package ar.com.centro8.java.curso.cuentas;


import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter 

public class CuentaConvertibilidad extends CuentaCorriente{
    private double saldoDolares;


    //constructor
    public CuentaConvertibilidad(int numeroCuenta, Cliente cliente, double saldo, double montoDescubierto) {
        super(numeroCuenta, cliente, saldo, montoDescubierto);
        this.saldoDolares = 0.0;
    }

    // metodo: depositar dolares
    public void depositarDolares(double monto){
        if (monto>0){
            saldoDolares+=monto;
        }
    }

    // metodo: extraer dolares: (para los dolares no se acepta el giro en descubierto)
    public void extraerDolares(double monto){
        if (monto>0 && monto<=saldoDolares){
            saldoDolares-=monto;
        }
    }

    // metodo: convertir pesos a dolares. (La tasa de conversión será un parámetro)
    public void convertirPesosADolares(double monto, double tasaConversion) {
        if (monto > 0 && monto <= getSaldo()) {
            double dolares = monto / tasaConversion;
            setSaldo(getSaldo() - monto); //  Descuenta los pesos
            saldoDolares += dolares;   //  Aumenta los dólares
        }
    }

    // metodo: convertir dolares a pesos. (La tasa de conversión será un parámetro)
    public void convertirDolaresAPesos(double monto, double tasaConversion){
        if (monto>0 && monto<=saldoDolares){
            double pesos = monto * tasaConversion;
            saldoDolares -= monto;
            setSaldo(getSaldo() + pesos);
        }
    }
}
