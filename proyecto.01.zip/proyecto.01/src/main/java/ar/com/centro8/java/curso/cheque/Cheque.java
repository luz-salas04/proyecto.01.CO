package ar.com.centro8.java.curso.cheque;

import java.time.LocalDate;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString 

public class Cheque {
    private double monto;
    private String bancoEmisor;
    private LocalDate fechaPago;

    // constructor
    public Cheque(double monto, String bancoEmisor, LocalDate fechaPago) {
        this.monto = monto;
        this.bancoEmisor = bancoEmisor;
        this.fechaPago = fechaPago;
    }
}
