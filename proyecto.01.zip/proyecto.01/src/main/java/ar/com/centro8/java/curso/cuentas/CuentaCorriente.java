package ar.com.centro8.java.curso.cuentas;


import ar.com.centro8.java.curso.cheque.Cheque;
import ar.com.centro8.java.curso.clientes.Cliente;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter  

public class CuentaCorriente extends Cuenta{
    private double montoDescubierto;

    // constructor
    public CuentaCorriente(int numeroCuenta, Cliente cliente, double saldo, double montoDescubierto) {
        super(numeroCuenta, cliente, saldo);
        this.montoDescubierto = montoDescubierto;
    }

    // metodos
    //Extraer efectivo: el cliente puede extraer dinero y utilizar su giro en descubierto en caso de 
    //que no tenga saldo suficiente
    @Override
    public void extraer(double monto) {
        if (monto>0 && monto<=(getSaldo()+montoDescubierto)){
            setSaldo(getSaldo()-monto);
        }
    }

    //Depositar cheques: el cliente puede depositar un cheque. Un cheque tiene un monto, un 
    //banco emisor y una fecha de pago
    // Cambia los 3 parámetros individuales por el objeto Cheque
    public void depositarCheque(Cheque cheque) {
        if (cheque != null && cheque.getMonto() > 0) {
            setSaldo(getSaldo() + cheque.getMonto());
        }
    }
}
