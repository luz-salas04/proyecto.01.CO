package ar.com.centro8.java.curso.clientes;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter 
@Setter
@ToString 

public class ClienteIndividual extends Cliente {
    private String nombre;
    private String apellido;
    private String dni;


    //constructor
    public ClienteIndividual(int numeroCliente, String nombre, String apellido, String dni) {
        super(numeroCliente); // llama al constructor de la clase padre
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
    }
}
